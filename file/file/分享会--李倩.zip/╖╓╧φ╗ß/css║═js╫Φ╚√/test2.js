// 循环5秒钟
var n1 = Number(new Date());
var n2 = Number(new Date());
while((n2 - n1)<(6*1000)){
	n2 = Number(new Date());
}